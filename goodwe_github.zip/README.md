# PRINT 4 – GoodWe Smart Charging Station

Estação inteligente de recarga de veículos elétricos (simulada) com **Raspberry Pi Pico + MicroPython + Wokwi**, inspirada no conceito do GoodWe Smart Energy Controller: gerenciar uma quantidade limitada de energia entre vários veículos.

## Arquivos
| Arquivo | Função |
|---|---|
| `main.py` | Programa único: driver do LCD, algoritmo (`alocar`), entradas, LEDs, LCD e Serial |
| `diagram.json` | Circuito do Wokwi |

## Hardware simulado
- Raspberry Pi Pico (processador central)
- 3 EVs × 3 LEDs (verde/amarelo/vermelho): EV1 GP0/1/2, EV2 GP6/7/8, EV3 GP13/14/15
- 3 botões: GP10 (troca situação 1→2→3), GP11 (preset ↔ potenciômetro), GP12 (reinicia baterias)
- Potenciômetro em GP26 (ADC): energia disponível manual de 0 a 10.000 W
- LCD 20x4 I2C (SDA GP4, SCL GP5, endereço 0x27)
- Monitor Serial (UART/USB)

## Como executar no Wokwi
1. Crie um projeto **Raspberry Pi Pico (MicroPython)** em wokwi.com.
2. Substitua o `diagram.json` e o `main.py` (não é preciso criar outros arquivos).
3. Clique em Play. Use o botão verde para alternar as situações.

## Fluxo do sistema
```
ENTRADAS: energia disponível (preset/potenciômetro) | bateria dos EVs | potência solicitada
        ↓
RASPBERRY PI PICO (MicroPython) – dados em RAM (lista de dicts)
        ↓
ALGORITMO (gerenciador.alocar)
        ↓
EV1 / EV2 / EV3 → LEDs + LCD I2C + Monitor Serial
```
Respostas às perguntas do enunciado:
- **Que dados entram?** Energia disponível, % de bateria e potência pedida de cada EV, comandos dos botões.
- **Como o Pico processa?** O laço principal lê as entradas e chama `alocar()`; a cada 1 s também atualiza as baterias.
- **Onde ficam os dados?** Na RAM, na lista `evs` (dicionários), mais variáveis de estado (`cen`, `manual`). O programa fica na flash.
- **Como decide?** Algoritmo abaixo.
- **Que saídas?** 9 LEDs, LCD 20x4 e Serial.

## Algoritmo: prioridade por bateria + potência mínima
1. Se `disponível ≥ demanda` → todos recebem o que pediram (verde).
2. Senão, ordena os EVs pela **menor bateria primeiro** (quem está mais "descarregado" tem prioridade).
3. **Fase 1 (garantia):** cada EV, em ordem, recebe a **potência mínima de 1.400 W** enquanto houver energia. Quem não couber fica em **espera** (vermelho).
4. **Fase 2 (sobra):** a energia restante é entregue aos EVs que já estão carregando, em ordem de prioridade, até o limite do pedido. Quem recebe menos que pediu fica **amarelo**.
5. Veículos com bateria 100% saem da disputa (LEDs apagados).

**Justificativa técnica:** pela IEC 61851 a corrente mínima de recarga é 6 A; em 230 V são ≈1.380 W (arredondado para 1.400 W). Dar menos que isso a um carro não carrega nada; por isso é melhor atender menos veículos com potência útil do que todos com potência inútil. A soma entregue nunca ultrapassa a energia disponível (verificado em testes).

### Resultados (EV1=20%, EV2=65%, EV3=40%; pedidos 2000/2500/3000 W)
| Situação | Disponível | EV1 | EV2 | EV3 | Status |
|---|---|---|---|---|---|
| 1 – Alta | 8.000 W | 2000 W 🟢 | 2500 W 🟢 | 3000 W 🟢 | RECARGA ATIVA |
| 2 – Limitada | 5.000 W | 2000 W 🟢 | 1400 W 🟡 | 1600 W 🟡 | RECARGA CONTROLADA |
| 3 – Baixa | 2.000 W | 2000 W 🟢 | 0 W 🔴 | 0 W 🔴 | RECARGA LIMITADA |

Obs.: na Situação 3 sobra energia para atender EV1 por completo, então ele fica verde (recebe 100% do pedido) e os outros dois esperam. Conforme as baterias sobem, a prioridade muda dinamicamente.

## Representação de dados
Energia disponível = 5000 W
- Decimal: `5000`
- Hexadecimal: `0x1388`
- Binário: `0b1001110001000` (13 bits; em 16 bits: `0001001110001000`)

Também aparecem no Serial a leitura do ADC (16 bits, 0–65535 → 0–10.000 W) e a **palavra de saída dos LEDs** de 9 bits (`R3Y3G3 R2Y2G2 R1Y1G1`), onde cada bit é um pino GPIO.

## Arquitetura de Computadores no projeto
| Conceito | Aplicação |
|---|---|
| Processador | RP2040 (dual-core ARM Cortex-M0+) do Pico |
| Representação de dados | W como inteiros, bateria em float, ADC de 16 bits |
| Sistemas numéricos | Decimal/hex/binário no Serial; palavra de 9 bits dos LEDs |
| Memória | Flash (código), RAM (lista `evs`, `gc.mem_free()` no Serial) |
| Entrada | Botões, potenciômetro (ADC), dados simulados |
| Processamento | `alocar()` e `status_sistema()` |
| Saída | LEDs (GPIO), LCD, Serial |
| Comunicação | I2C (LCD, endereço 0x27) e serial |
| Automação | Decisão automática de quem recarrega e com quanta potência |

## Relação com a GoodWe
O GoodWe Smart Energy Controller equilibra geração (solar), consumo da casa e recarga do EV. Aqui simplificamos: a "energia disponível" representa a sobra de geração/rede, e o Pico divide essa sobra entre vários veículos de forma automática. Não reproduz o produto comercial; é uma versão educacional do conceito.
