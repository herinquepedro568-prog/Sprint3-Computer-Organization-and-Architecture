# GoodWe Smart Charging Station - simulacao educacional
# Raspberry Pi Pico + MicroPython + Wokwi  (ARQUIVO UNICO)
#
# ENTRADAS : botoes (situacao / modo / reset), potenciometro, dados dos EVs
# PROCESSA : funcao alocar() -> decide a potencia de cada EV
# MEMORIA  : lista 'evs' (dicionarios) na RAM
# SAIDAS   : 9 LEDs, LCD I2C 20x4, Monitor Serial
import gc
from machine import Pin, I2C, ADC
from time import ticks_ms, ticks_diff, sleep_ms, sleep_us

# ===================== CONFIGURACAO =====================
ENERGIAS = (8000, 5000, 2000)   # Situacao 1, 2, 3 (W)
P_MIN = 1400                    # W - potencia minima de recarga (6 A x 230 V, IEC 61851)
CAP_WH = 40000                  # bateria de cada EV: 40 kWh
ACEL = 600                      # 1 s real = 600 s simulados

ATIVA = "ATIVA"
REDUZIDA = "REDUZIDA"
ESPERA = "ESPERA"
CHEIO = "CHEIO"
TAG = {ATIVA: "ATIV", REDUZIDA: "REDU", ESPERA: "ESPR", CHEIO: "FULL"}

# Memoria da sessao: id, bateria (%), potencia solicitada (W), potencia dada, estado
evs = [
    {"id": 1, "soc": 20.0, "req": 2000, "p": 0, "estado": ESPERA},
    {"id": 2, "soc": 65.0, "req": 2500, "p": 0, "estado": ESPERA},
    {"id": 3, "soc": 40.0, "req": 3000, "p": 0, "estado": ESPERA},
]
SOC_INICIAL = [20.0, 65.0, 40.0]


# ===================== DRIVER LCD I2C (PCF8574) =====================
class LCD:
    LINHAS = (0x00, 0x40, 0x14, 0x54)

    def __init__(self, i2c, addr=0x27, cols=20):
        self.i2c = i2c
        self.addr = addr
        self.cols = cols
        sleep_ms(50)
        for _ in range(3):
            self.nibble(0x3, 0)
            sleep_ms(5)
        self.nibble(0x2, 0)
        self.cmd(0x28)
        self.cmd(0x0C)
        self.cmd(0x06)
        self.clear()

    def wr(self, b):
        self.i2c.writeto(self.addr, bytes([(b | 0x08) & 0xFF]))

    def nibble(self, n, rs):
        b = (n << 4) | rs
        self.wr(b | 0x04)
        sleep_us(5)
        self.wr(b & 0xFB)
        sleep_us(80)

    def cmd(self, c):
        self.nibble(c >> 4, 0)
        self.nibble(c & 0x0F, 0)

    def clear(self):
        self.cmd(0x01)
        sleep_ms(3)

    def put(self, linha, texto):
        self.cmd(0x80 | self.LINHAS[linha])
        texto = (texto + " " * self.cols)[:self.cols]
        for ch in texto:
            c = ord(ch)
            self.nibble(c >> 4, 1)
            self.nibble(c & 0x0F, 1)


# ===================== ALGORITMO DE GERENCIAMENTO =====================
def chave(e):
    return e["soc"]          # menor bateria = maior prioridade


def alocar(disponivel):
    """Define e['p'] e e['estado'] de cada EV. Retorna a demanda total (W)."""
    for e in evs:
        e["p"] = 0
        e["estado"] = CHEIO if e["soc"] >= 100 else ESPERA

    ativos = [e for e in evs if e["soc"] < 100]
    demanda = 0
    for e in ativos:
        demanda += e["req"]

    if disponivel >= demanda:                 # energia suficiente
        for e in ativos:
            e["p"] = e["req"]
    else:                                     # energia insuficiente
        ordem = sorted(ativos, key=chave)
        resto = disponivel
        for e in ordem:                       # fase 1: potencia minima
            m = min(P_MIN, e["req"])
            if resto >= m:
                e["p"] = m
                resto -= m
        for e in ordem:                       # fase 2: distribui a sobra
            if e["p"] > 0:
                extra = min(e["req"] - e["p"], resto)
                e["p"] += extra
                resto -= extra

    for e in ativos:
        if e["p"] == 0:
            e["estado"] = ESPERA
        elif e["p"] >= e["req"]:
            e["estado"] = ATIVA
        else:
            e["estado"] = REDUZIDA
    return demanda


def status_sistema():
    ativos = [e for e in evs if e["soc"] < 100]
    if len(ativos) == 0:
        return "CONCLUIDA"
    for e in ativos:
        if e["estado"] == ESPERA:
            return "LIMITADA"
    for e in ativos:
        if e["estado"] == REDUZIDA:
            return "CONTROLADA"
    return "ATIVA"


# ===================== HARDWARE =====================
leds = [
    [Pin(0, Pin.OUT), Pin(1, Pin.OUT), Pin(2, Pin.OUT)],       # EV1: G, Y, R
    [Pin(6, Pin.OUT), Pin(7, Pin.OUT), Pin(8, Pin.OUT)],       # EV2
    [Pin(13, Pin.OUT), Pin(14, Pin.OUT), Pin(15, Pin.OUT)],    # EV3
]
btn_cen = Pin(10, Pin.IN, Pin.PULL_UP)     # troca situacao
btn_modo = Pin(11, Pin.IN, Pin.PULL_UP)    # preset <-> potenciometro
btn_rst = Pin(12, Pin.IN, Pin.PULL_UP)     # reinicia baterias
pot = ADC(26)

try:
    lcd = LCD(I2C(0, sda=Pin(4), scl=Pin(5), freq=400000), 0x27, 20)
except OSError:
    lcd = None
    print("AVISO: LCD nao encontrado (confira ligacao/endereco 0x27)")

cen = 0
manual = False


# ===================== FUNCOES DE E/S =====================
def ler_energia():
    if manual:                               # ADC 16 bits -> 0..10000 W
        return (pot.read_u16() * 10000 // 65535) // 100 * 100
    return ENERGIAS[cen]


def atualizar_leds():
    """Palavra de saida de 9 bits: G,Y,R de EV1..EV3. Cada bit = 1 pino GPIO."""
    palavra = 0
    for i in range(3):
        est = evs[i]["estado"]
        if est == ATIVA:
            palavra |= 1 << (3 * i)
        elif est == REDUZIDA:
            palavra |= 2 << (3 * i)
        elif est == ESPERA:
            palavra |= 4 << (3 * i)
    for i in range(3):
        for j in range(3):
            leds[i][j].value((palavra >> (3 * i + j)) & 1)
    return palavra


def mostrar_lcd(disp, dem, st):
    if lcd is None:
        return
    lcd.put(0, "Disp%5dW Dem%5dW" % (disp, dem))
    for i in range(3):
        e = evs[i]
        lcd.put(i + 1, "EV%d %3d%% %4dW %s" % (e["id"], int(e["soc"]), e["p"], TAG[e["estado"]]))
    if manual:
        modo = "MAN"
    else:
        modo = "S" + str(cen + 1)
    lcd.put(3, "Modo:" + modo + " " + st)


def mostrar_serial(disp, dem, st, palavra):
    if manual:
        nome = "MANUAL"
    else:
        nome = str(cen + 1)
    print("=" * 50)
    print("Situacao " + nome + " | STATUS: RECARGA " + st)
    print("Energia disponivel: %d W | Demanda total: %d W" % (disp, dem))
    print("  Dec: %d | Hex: %s | Bin: %s" % (disp, hex(disp), bin(disp)))
    for e in evs:
        print("  EV%d  bat=%5.1f%%  pedido=%4d W  recebe=%4d W  -> %s" %
              (e["id"], e["soc"], e["req"], e["p"], e["estado"]))
    print("  LEDs (R3Y3G3 R2Y2G2 R1Y1G1): " + bin(palavra + 512)[3:] +
          " | RAM livre: %d B" % gc.mem_free())


def reavaliar():
    disp = ler_energia()
    dem = alocar(disp)
    st = status_sistema()
    pal = atualizar_leds()
    mostrar_lcd(disp, dem, st)
    mostrar_serial(disp, dem, st, pal)


def pressionado(btn):
    if btn.value() == 0:
        sleep_ms(30)                         # debounce
        if btn.value() == 0:
            while btn.value() == 0:
                sleep_ms(10)
            return True
    return False


# ===================== PROGRAMA PRINCIPAL =====================
print("GoodWe Smart Charging Station - iniciando")
reavaliar()
t_ant = ticks_ms()

while True:
    if pressionado(btn_cen):
        cen = (cen + 1) % 3
        manual = False
        reavaliar()
    if pressionado(btn_modo):
        manual = not manual
        reavaliar()
    if pressionado(btn_rst):
        for i in range(3):
            evs[i]["soc"] = SOC_INICIAL[i]
        reavaliar()

    agora = ticks_ms()
    if ticks_diff(agora, t_ant) >= 1000:     # tick de 1 s
        dt = ticks_diff(agora, t_ant) / 1000
        t_ant = agora
        for e in evs:                        # energia entregue -> bateria
            novo = e["soc"] + e["p"] * dt * ACEL / 3600 / CAP_WH * 100
            e["soc"] = 100.0 if novo > 100.0 else novo
        reavaliar()
    sleep_ms(20)
